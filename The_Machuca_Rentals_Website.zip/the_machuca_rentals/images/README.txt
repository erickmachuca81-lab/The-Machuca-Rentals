Replace hero.jpg, event-1.jpg, event-2.jpg and event-3.jpg with your real photos.
Then replace YOUR_EMAIL_HERE and YOUR PHONE HERE in index.html.

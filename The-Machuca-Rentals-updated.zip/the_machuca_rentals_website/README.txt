# The Machuca Rentals website

This package contains:
- index.html — complete updated website
- assets/ — the two photos supplied for the website

Replace the existing `index.html` in the GitHub Pages repository with this one, and upload the `assets` folder with the two images.
